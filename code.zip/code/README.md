# align-lab

Companion code for the article **"AI Does What You Measure, Not What You Mean:
A Hands-On Look at Reward Hacking."**

A faithful, tiny re-creation of DeepMind's "boat race" AI Safety Gridworld
(Leike et al., 2017), used to demonstrate **reward hacking** live: an agent
trained on a proxy reward learns to farm points instead of doing the task.

> **What this is.** A minimal, fully-inspectable testbed: tabular Q-learning on a
> 5x5 grid, pure NumPy, no GPU. It reproduces the *mechanism* of reward hacking
> that shows up in frontier systems, at a scale you can watch and fully understand.

## Quick start

```bash
pip install -r requirements.txt
python run_all.py
```

Results land in `results/` (JSON), figures and the animation in `figures/`.

## Layout

```
gridlab/
  boatrace.py   the boat-race gridworld, with separate proxy and true rewards
  qlearn.py     tabular Q-learning agent + training/rollout/trace helpers
experiments/
  e1_hacking.py    proxy-trained vs true-trained agent (the core demonstration)
  e2_threshold.py  how much true signal is needed to beat the proxy (phase transition)
  e3_fixes.py      five reward designs: which get gamed, which hold
viz/
  style.py         shared light-theme design system (IBM Plex Sans)
  make_figures.py  the static charts
  make_gif.py      the reward-hacker-vs-honest-racer animation
  cover.py         the article cover
run_all.py     reproduces everything
```

## Headline results (from this code, seeds fixed)

| Experiment | Finding |
|---|---|
| E1 | Proxy-trained agent: proxy 75 / true 20 / 1 lap. True-trained: proxy 12 / true 50 / 3 laps. It games the metric. |
| E2 | Sharp phase transition: blending true signal does nothing until weight ~0.44, then behavior snaps to honest. |
| E3 | "Penalize idling" and "potential shaping" are still gamed; only rewarding true progress works. |

## License

Code: MIT.
