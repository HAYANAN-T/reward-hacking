"""Reproduce every result, figure, and the animation in the article.

    python run_all.py      # ~4-6 minutes on a laptop CPU
"""
import subprocess, sys, pathlib, time
ROOT = pathlib.Path(__file__).resolve().parent
STEPS = ["experiments/e1_hacking.py", "experiments/e2_threshold.py",
         "experiments/e3_fixes.py", "viz/make_figures.py",
         "viz/make_gif.py", "viz/cover.py"]
for step in STEPS:
    t = time.time(); print(f"\n=== {step}")
    subprocess.run([sys.executable, str(ROOT / step)], check=True, cwd=ROOT)
    print(f"--- done in {time.time()-t:.1f}s")
