"""
E2 - How much honesty do you have to buy?

A common industry fix for reward hacking is to mix a little of the "true" signal
into the proxy reward. We test exactly how much is needed. The training reward is

    reward = (1 - w) * proxy  +  w * (true * scale)

and we sweep the true-signal weight w from 0 (pure proxy) to 1 (pure true). For
each w we train 30 agents and measure the true reward they actually achieve.

The result is a sharp phase transition, not a gentle trade-off: below a threshold
weight the extra true signal does almost nothing (the agent still farms), and only
once w crosses the threshold does behavior snap to honest racing. Partial fixes
buy you almost nothing until they suddenly buy you everything.
"""
import json, sys, pathlib
import numpy as np

ROOT = pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from gridlab.boatrace import BoatRace
from gridlab.qlearn import QLearner, rollout

HORIZON = 50
EPISODES = 2000
SEEDS = 20
SCALE = 3.0
WEIGHTS = [0.0, 0.1, 0.2, 0.3, 0.4, 0.44, 0.48, 0.5, 0.6, 0.8, 1.0]


def train_mix(w, seed):
    env = BoatRace()
    agent = QLearner(env.n_states, gamma=0.95, seed=seed)
    for ep in range(EPISODES):
        frac = ep / EPISODES
        eps = 1.0 + (0.05 - 1.0) * frac
        env.reset(); s = env.state_id(env.pos)
        for t in range(HORIZON):
            a = agent.act(s, eps)
            pos, p, tr, m = env.step(a)
            r = (1 - w) * p + w * (tr * SCALE)
            agent.update(s, a, r, env.state_id(pos))
            s = env.state_id(pos)
    return env, agent


def main():
    true_mean, true_ci, hack_rate = [], [], []
    for w in WEIGHTS:
        ts = []
        for seed in range(SEEDS):
            env, agent = train_mix(w, seed)
            p, tr, laps = rollout(env, agent, HORIZON)
            ts.append(tr)
        ts = np.array(ts)
        true_mean.append(float(ts.mean()))
        true_ci.append(float(1.96 * ts.std(ddof=1) / np.sqrt(SEEDS)))
        hack_rate.append(float(np.mean(ts < 35)))
        print(f"w={w:.2f}: true={ts.mean():5.1f}  hack_rate={np.mean(ts<35):.0%}", flush=True)
        json.dump(dict(weights=WEIGHTS[:len(true_mean)], true_mean=true_mean,
                       true_ci=true_ci, hack_rate=hack_rate, honest_max=50.0, scale=SCALE),
                  open(ROOT / "results/e2_threshold.json", "w"), indent=2)
    out = dict(weights=WEIGHTS, true_mean=true_mean, true_ci=true_ci,
               hack_rate=hack_rate, honest_max=50.0, scale=SCALE)
    json.dump(out, open(ROOT / "results/e2_threshold.json", "w"), indent=2)


if __name__ == "__main__":
    main()
