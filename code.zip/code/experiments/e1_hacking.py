"""
E1 - The gap between the reward and the goal.

We train two identical Q-learning agents on the boat-race gridworld. One is given
the proxy reward (points for arrow-aligned moves), the other the true reward
(genuine lap progress). We track BOTH signals over training for BOTH agents.

The proxy agent's proxy score soars while its true score flatlines: it has learned
to farm points by oscillating on one tile instead of racing. This is reward hacking,
measured directly.
"""
import json, sys, pathlib
import numpy as np

ROOT = pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from gridlab.boatrace import BoatRace
from gridlab.qlearn import train

EPISODES = 6000
HORIZON = 50
SEEDS = 12


def run(reward_fn, seed):
    env = BoatRace()
    _, h = train(env, reward_fn, episodes=EPISODES, horizon=HORIZON, seed=seed)
    return h


def aggregate(reward_fn):
    runs = [run(reward_fn, s) for s in range(SEEDS)]
    eps = runs[0]["episode"]
    proxy = np.array([r["proxy"] for r in runs])
    true = np.array([r["true"] for r in runs])
    laps = np.array([r["laps"] for r in runs])
    def ms(x):
        return x.mean(0).tolist(), (1.96 * x.std(0, ddof=1) / np.sqrt(len(x))).tolist()
    pm, pc = ms(proxy); tm, tc = ms(true); lm, lc = ms(laps)
    return dict(episode=eps, proxy_mean=pm, proxy_ci=pc, true_mean=tm, true_ci=tc,
                laps_mean=lm, laps_ci=lc)


def main():
    out = {"proxy_agent": aggregate(lambda p, t, m: p),
           "true_agent": aggregate(lambda p, t, m: t),
           "horizon": HORIZON}
    (ROOT / "results").mkdir(exist_ok=True)
    json.dump(out, open(ROOT / "results/e1_hacking.json", "w"), indent=2)
    pa, ta = out["proxy_agent"], out["true_agent"]
    print(f"proxy agent final: proxy={pa['proxy_mean'][-1]:.0f}  "
          f"true={pa['true_mean'][-1]:.1f}  laps={pa['laps_mean'][-1]:.2f}")
    print(f"true  agent final: proxy={ta['proxy_mean'][-1]:.0f}  "
          f"true={ta['true_mean'][-1]:.1f}  laps={ta['laps_mean'][-1]:.2f}")


if __name__ == "__main__":
    main()
