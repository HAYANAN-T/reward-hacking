"""
E2 - Goodhart's law in miniature: the more you optimize the proxy, the less it
measures what you want.

"When a measure becomes a target, it ceases to be a good measure." We show this
literally. We take many snapshots of an agent as it trains on the proxy reward,
and for each snapshot plot its proxy score against its true score. Early in
training the two rise together (the agent is just learning to move). Past a
turning point they DECOUPLE: proxy keeps climbing while true reward collapses as
the agent abandons racing for farming.

We also report the running correlation between proxy and true across the
population, which flips from strongly positive to negative.
"""
import json, sys, pathlib
import numpy as np

ROOT = pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from gridlab.boatrace import BoatRace
from gridlab.qlearn import QLearner, rollout

HORIZON = 50
SEEDS = 60
CKPTS = [5, 10, 15, 20, 30, 45, 70, 110, 180, 300, 600, 1500, 4000]


def main():
    proxy = np.zeros((SEEDS, len(CKPTS)))
    true = np.zeros((SEEDS, len(CKPTS)))
    for si in range(SEEDS):
        env = BoatRace()
        agent = QLearner(env.n_states, gamma=0.95, seed=si)
        ep = 0
        for ci, target in enumerate(CKPTS):
            while ep < target:
                frac = min(ep / 4000, 1.0)
                eps = 1.0 + (0.05 - 1.0) * frac
                env.reset(); s = env.state_id(env.pos)
                for t in range(HORIZON):
                    a = agent.act(s, eps)
                    pos, p, tr, m = env.step(a)
                    agent.update(s, a, p, env.state_id(pos))   # train on PROXY
                    s = env.state_id(pos)
                ep += 1
            p, tr, laps = rollout(env, agent, HORIZON)
            proxy[si, ci] = p; true[si, ci] = tr

    corr = []
    for ci in range(len(CKPTS)):
        if proxy[:, ci].std() > 1e-6 and true[:, ci].std() > 1e-6:
            corr.append(float(np.corrcoef(proxy[:, ci], true[:, ci])[0, 1]))
        else:
            corr.append(0.0)

    out = dict(
        checkpoints=CKPTS,
        proxy_mean=proxy.mean(0).tolist(),
        proxy_ci=(1.96 * proxy.std(0, ddof=1) / np.sqrt(SEEDS)).tolist(),
        true_mean=true.mean(0).tolist(),
        true_ci=(1.96 * true.std(0, ddof=1) / np.sqrt(SEEDS)).tolist(),
        correlation=corr,
    )
    json.dump(out, open(ROOT / "results/e2_goodhart.json", "w"), indent=2)
    for ci, c in enumerate(CKPTS):
        print(f"ep {c:5d}: proxy={proxy[:,ci].mean():5.1f}  true={true[:,ci].mean():5.1f}  "
              f"corr={corr[ci]:+.2f}")


if __name__ == "__main__":
    main()
