"""
gridlab.qlearn - a plain tabular Q-learning agent.

It optimizes exactly the reward signal it is handed. Point it at the proxy
reward and it will happily learn to reward-hack; point it at a well-shaped
reward and it will learn to actually race. The agent is identical in both
cases: only the reward design changes. That is the article's core claim, made
mechanical.
"""
from __future__ import annotations
import numpy as np


class QLearner:
    def __init__(self, n_states, n_actions=4, alpha=0.5, gamma=0.95,
                 eps_start=1.0, eps_end=0.05, seed=0):
        self.Q = np.zeros((n_states, n_actions))
        self.n_actions = n_actions
        self.alpha, self.gamma = alpha, gamma
        self.eps_start, self.eps_end = eps_start, eps_end
        self.rng = np.random.default_rng(seed)

    def act(self, s, eps):
        if self.rng.random() < eps:
            return self.rng.integers(self.n_actions)
        q = self.Q[s]
        return int(self.rng.choice(np.flatnonzero(q == q.max())))

    def update(self, s, a, r, s2):
        target = r + self.gamma * self.Q[s2].max()
        self.Q[s, a] += self.alpha * (target - self.Q[s, a])


def train(env, reward_fn, episodes=4000, horizon=40, seed=0, eval_every=100):
    """Train a Q-learner on a chosen reward. Log BOTH proxy and true reward.

    reward_fn(proxy, true, moved) -> scalar training reward.
    Returns history dicts of proxy and true reward per evaluation point.
    """
    agent = QLearner(env.n_states, seed=seed)
    hist = {"episode": [], "proxy": [], "true": [], "laps": []}
    for ep in range(episodes):
        frac = ep / episodes
        eps = agent.eps_start + (agent.eps_end - agent.eps_start) * frac
        env.reset()
        s = env.state_id(env.pos)
        for t in range(horizon):
            a = agent.act(s, eps)
            pos, proxy, true, moved = env.step(a)
            s2 = env.state_id(pos)
            agent.update(s, a, reward_fn(proxy, true, moved), s2)
            s = s2
        if ep % eval_every == 0:
            p, tr, laps = rollout(env, agent, horizon)
            hist["episode"].append(ep)
            hist["proxy"].append(p)
            hist["true"].append(tr)
            hist["laps"].append(laps)
    return agent, hist


def rollout(env, agent, horizon=40, greedy=True):
    """Run one greedy episode; return total proxy, total true, laps."""
    env.reset()
    s = env.state_id(env.pos)
    tot_p = tot_t = 0.0
    for t in range(horizon):
        a = agent.act(s, 0.0 if greedy else 0.1)
        pos, proxy, true, moved = env.step(a)
        tot_p += proxy; tot_t += true
        s = env.state_id(pos)
    return tot_p, tot_t, env.laps


def trace(env, agent, horizon=40):
    """Return the sequence of positions a greedy agent visits (for animation)."""
    env.reset()
    s = env.state_id(env.pos)
    path = [env.pos]
    for t in range(horizon):
        a = agent.act(s, 0.0)
        pos, proxy, true, moved = env.step(a)
        path.append(pos)
        s = env.state_id(pos)
    return path
