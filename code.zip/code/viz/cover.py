"""Cover: the reward-hacker boat farming one tile, with title."""
import sys, pathlib
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, Rectangle, Circle, FancyArrowPatch
ROOT = pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from viz.style import *  # noqa
from gridlab.boatrace import BoatRace, ARROW
PROXY = AGGRESSIVE; TRUE = GOOD

def main():
    env = BoatRace()
    fig = plt.figure(figsize=(8, 4.5), facecolor="#F3F6FA")
    fig.text(0.06, 0.72, "AI does what", fontsize=33, fontweight="bold", color=INK, va="center")
    fig.text(0.06, 0.605, "you measure", fontsize=33, fontweight="bold", color=PROXY, va="center")
    fig.text(0.06, 0.44, "Not what you mean. A hands-on look at reward\nhacking, the everyday face of the AI\nalignment problem, in code you can run",
             fontsize=11.5, color=SUB, va="center", linespacing=1.5)
    fig.text(0.06, 0.13, "Right: a real agent I trained. Paid for points, it farms one tile forever\n(red loop) instead of finishing the race.",
             fontsize=7.6, color=FAINT, linespacing=1.4)
    ax = fig.add_axes([0.55, 0.12, 0.40, 0.76]); ax.set_xlim(-0.5, env.w-0.5); ax.set_ylim(-0.5, env.h-0.5)
    ax.set_aspect("equal"); ax.axis("off"); ax.invert_yaxis()
    for r in range(env.h):
        for c in range(env.w):
            ch = env.grid[r][c]
            if ch == "#":
                ax.add_patch(Rectangle((c-0.5,r-0.5),1,1,fc="#DFE5EC",ec="white",lw=1))
            else:
                fc="#FCE9E7" if ch in ARROW else "#F5F8FC"
                ax.add_patch(FancyBboxPatch((c-0.42,r-0.42),0.84,0.84,boxstyle="round,pad=0,rounding_size=0.08",
                             fc=fc,ec="#E2E8F0",lw=1))
                if ch in ARROW:
                    ax.text(c,r,"→",ha="center",va="center",fontsize=15,color=PROXY,fontweight="bold")
    # the farming oscillation loop arrow between (1,1) and (1,2)
    ax.add_patch(FancyArrowPatch((1,1.32),(2,1.32),arrowstyle="-|>",mutation_scale=13,color=PROXY,lw=2,
                 connectionstyle="arc3,rad=0.5"))
    ax.add_patch(FancyArrowPatch((2,0.68),(1,0.68),arrowstyle="-|>",mutation_scale=13,color=PROXY,lw=2,
                 connectionstyle="arc3,rad=0.5"))
    ax.add_patch(Circle((1,1),0.28,fc=RESTRAINED,ec="white",lw=2,zorder=5))
    fig.savefig(ROOT/"figures/cover.png", dpi=200, facecolor=fig.get_facecolor())
    print("cover.png")

if __name__ == "__main__":
    main()
