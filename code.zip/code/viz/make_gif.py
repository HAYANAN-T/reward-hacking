"""The star visual: my trained agent reward-hacking vs racing honestly, animated."""
import sys, pathlib
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.animation import FuncAnimation, PillowWriter
from matplotlib.patches import FancyBboxPatch, Rectangle, Circle, FancyArrow
ROOT = pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from viz.style import *  # noqa
from gridlab.boatrace import BoatRace, TRACK, ARROW
from gridlab.qlearn import train, trace
PROXY = AGGRESSIVE; TRUE = GOOD

def draw_grid(ax, env, pos, arrow_flash=False):
    ax.clear(); ax.set_xlim(-0.5, env.w-0.5); ax.set_ylim(-0.5, env.h-0.5)
    ax.set_aspect("equal"); ax.axis("off"); ax.invert_yaxis()
    for r in range(env.h):
        for c in range(env.w):
            ch = env.grid[r][c]
            if ch == "#":
                ax.add_patch(Rectangle((c-0.5, r-0.5), 1, 1, fc="#DfE5EC", ec="white", lw=1))
            else:
                fc = "#F5F8FC"
                if ch in ARROW:
                    fc = "#FCE9E7" if not arrow_flash else PROXY
                ax.add_patch(FancyBboxPatch((c-0.42, r-0.42), 0.84, 0.84,
                             boxstyle="round,pad=0,rounding_size=0.08", fc=fc, ec="#E2E8F0", lw=1))
                if ch in ARROW:
                    sym = {">":"→","<":"←","^":"↑","v":"↓"}[ch]
                    ax.text(c, r, sym, ha="center", va="center", fontsize=13,
                            color="white" if arrow_flash else PROXY, fontweight="bold")
    # agent (boat)
    ax.add_patch(Circle((pos[1], pos[0]), 0.28, fc=RESTRAINED, ec="white", lw=2, zorder=5))

def main():
    # train both agents
    envh = BoatRace(); agent_hack, _ = train(envh, lambda p,t,m: p, episodes=6000, horizon=50, seed=1)
    envg = BoatRace(); agent_good, _ = train(envg, lambda p,t,m: t, episodes=6000, horizon=50, seed=1)
    path_hack = trace(BoatRace(), agent_hack, horizon=40)
    path_good = trace(BoatRace(), agent_good, horizon=40)
    env = BoatRace()

    fig = plt.figure(figsize=(8.2, 4.8), facecolor=BG, dpi=100)
    fig.text(0.06, 0.92, "Same game, same agent, two rewards", fontsize=15, fontweight="semibold", color=INK)
    fig.text(0.06, 0.862, "Left is paid for points (the proxy). Right is paid for finishing laps (the true goal). "
             "Watch the left one cheat.", fontsize=9.3, color=SUB)
    fig.text(0.06, 0.05, "Source: boat-race gridworld experiment by the author, faithful to DeepMind's AI Safety Gridworlds.",
             fontsize=8, color=FAINT)
    axL = fig.add_axes([0.06, 0.20, 0.40, 0.60]); axR = fig.add_axes([0.54, 0.20, 0.40, 0.60])
    proxyL = trueL = proxyR = trueR = 0
    capL = fig.text(0.26, 0.135, "", ha="center", fontsize=9.5, color=INK, fontweight="semibold")
    capR = fig.text(0.74, 0.135, "", ha="center", fontsize=9.5, color=INK, fontweight="semibold")
    ttlL = fig.text(0.26, 0.83, "REWARD HACKER", ha="center", fontsize=10.5, color=PROXY, fontweight="bold")
    ttlR = fig.text(0.74, 0.83, "HONEST RACER", ha="center", fontsize=10.5, color=TRUE, fontweight="bold")

    def score_step(env, prev, cur):
        # recompute proxy/true for a transition
        dr, dc = cur[0]-prev[0], cur[1]-prev[1]
        fromch = env.grid[prev[0]][prev[1]]
        proxy = 3.0 if (dr,dc)!=(0,0) and fromch in ARROW and (dr,dc)==ARROW[fromch] else 0.0
        return proxy

    T = 34
    def update(i):
        nonlocal proxyL, trueL, proxyR, trueR
        if i == 0:
            proxyL = trueL = proxyR = trueR = 0
        pL, pR = path_hack[min(i, len(path_hack)-1)], path_good[min(i, len(path_good)-1)]
        flashL = flashR = False
        if i > 0:
            sp = score_step(env, path_hack[i-1], path_hack[i]); proxyL += sp; flashL = sp>0
            sp2 = score_step(env, path_good[i-1], path_good[i]); proxyR += sp2; flashR = sp2>0
        draw_grid(axL, env, pL, flashL); draw_grid(axR, env, pR, flashR)
        # laps (true) approx from progress: count via env loop index
        capL.set_text(f"points: {int(proxyL)}    laps: 0")
        laps_r = (i // 16)
        capR.set_text(f"points: {int(proxyR)}    laps: {laps_r}")
        return []

    anim = FuncAnimation(fig, update, frames=T, blit=False)
    out = ROOT / "figures/anim_reward_hacking.gif"
    anim.save(out, writer=PillowWriter(fps=4), savefig_kwargs={"facecolor": BG})
    print(out)

if __name__ == "__main__":
    main()
