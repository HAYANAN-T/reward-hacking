"""Figures for the reward-hacking article, on the shared light theme."""
import json, sys, pathlib
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.gridspec import GridSpec
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch, Rectangle, Circle

ROOT = pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from viz.style import *  # noqa

R = ROOT / "results"
PROXY = AGGRESSIVE
TRUE = GOOD
NEUTRAL = "#9AA6B6"


def fig_hacking():
    j = json.load(open(R / "e1_hacking.json"))
    pa, ta = j["proxy_agent"], j["true_agent"]
    fig, gs = card(9.2, 5.0,
                   "The agent maximizes the reward, not the goal",
                   "Two identical agents. One is paid for the proxy (points), one for the true goal (laps).",
                   "Source: boat-race gridworld experiment by the author, 12 seeds. Shaded bands are 95% CIs.",
                   top=0.72, bottom=0.15, left=0.08, right=0.955)
    g = GridSpec(1, 2, figure=fig, wspace=0.28, **gs)
    ep = np.array(pa["episode"])
    ax = style_ax(fig.add_subplot(g[0]), "Training episodes", "Score")
    panel_title(ax, "Trained on the PROXY reward", "farms points, never races")
    for key, col, lab in [("proxy", PROXY, "Proxy score (what it's paid)"),
                          ("true", TRUE, "True score (what we want)")]:
        m = np.array(pa[f"{key}_mean"]); c = np.array(pa[f"{key}_ci"])
        ax.plot(ep, m, color=col, lw=2.6, label=lab)
        ax.fill_between(ep, m - c, m + c, color=col, alpha=0.13, lw=0)
        end_label(ax, ep[-1], m[-1], f"{m[-1]:.0f}", col, dy=0)
    ax.set_xlim(0, ep[-1]); ax.set_ylim(0, 85)
    ax.legend(loc="center right", fontsize=8.4)
    ax2 = style_ax(fig.add_subplot(g[1]), "Training episodes", "")
    panel_title(ax2, "Trained on the TRUE reward", "actually races")
    for key, col in [("proxy", PROXY), ("true", TRUE)]:
        m = np.array(ta[f"{key}_mean"]); c = np.array(ta[f"{key}_ci"])
        ax2.plot(ep, m, color=col, lw=2.6)
        ax2.fill_between(ep, m - c, m + c, color=col, alpha=0.13, lw=0)
        end_label(ax2, ep[-1], m[-1], f"{m[-1]:.0f}", col, dy=0)
    ax2.set_xlim(0, ep[-1]); ax2.set_ylim(0, 85)
    return save(fig, "e1_hacking.png")


def fig_threshold():
    j = json.load(open(R / "e2_threshold.json"))
    w = np.array(j["weights"]); m = np.array(j["true_mean"]); c = np.array(j["true_ci"])
    fig, gs = card(9.2, 5.0,
                   "Half-fixing the reward fixes nothing",
                   "True reward as we blend more of the 'true' signal into the proxy. Below a threshold, the extra signal is wasted.",
                   "Source: boat-race gridworld experiment by the author, 30 seeds per point. Honest max is 50; farming yields 20.",
                   top=0.72, bottom=0.15, left=0.09, right=0.80)
    ax = style_ax(fig.add_subplot(GridSpec(1, 1, figure=fig, **gs)[0]),
                  "Weight on the true signal in the reward", "True reward achieved")
    thr = w[np.argmax(m > 35)]
    ax.axvspan(0, thr, color=PROXY, alpha=0.05, lw=0)
    ax.axvspan(thr, 1, color=TRUE, alpha=0.05, lw=0)
    ax.plot(w, m, color=INK, lw=2.6, marker="o", ms=4.5, markerfacecolor=CARD, markeredgewidth=1.5)
    ax.fill_between(w, m - c, m + c, color=NEUTRAL, alpha=0.2, lw=0)
    ax.axhline(50, color=TRUE, lw=1, ls=(0, (3, 3))); ax.text(0.02, 51, "honest racing", color=TRUE, fontsize=8.5)
    ax.axhline(20, color=PROXY, lw=1, ls=(0, (3, 3))); ax.text(0.02, 21.5, "reward hacking", color=PROXY, fontsize=8.5)
    ax.annotate(f"snaps at w-{thr:.2f}", xy=(thr, 35), xytext=(thr + 0.12, 34),
                fontsize=9.5, color=INK, fontweight="semibold",
                arrowprops=dict(arrowstyle="-|>", color=FAINT, lw=1.2))
    ax.set_xlim(0, 1); ax.set_ylim(10, 56)
    return save(fig, "e2_threshold.png")


def fig_fixes():
    j = json.load(open(R / "e3_fixes.json"))
    names = list(j)
    fig, gs = card(9.2, 5.0,
                   "Which reward fixes actually hold?",
                   "Five reward designs on the same agent and world. Green reaches the honest goal; red is still gamed.",
                   "Source: boat-race gridworld experiment by the author, 24 seeds per design.",
                   top=0.74, bottom=0.13, left=0.26, right=0.94)
    ax = style_ax(fig.add_subplot(GridSpec(1, 1, figure=fig, **gs)[0]),
                  "True reward achieved (honest max = 50)", "")
    ax.grid(axis="y", visible=False); ax.grid(axis="x", visible=True)
    y = np.arange(len(names))[::-1]
    vals = [j[n]["true_mean"] for n in names]
    cols = [TRUE if j[n]["hack_rate"] < 0.5 else PROXY for n in names]
    ax.barh(y, vals, height=0.6, color=cols, zorder=3)
    for yy, n, v in zip(y, names, vals):
        tag = "gamed" if j[n]["hack_rate"] >= 0.5 else "works"
        ax.text(v + 0.8, yy, f"{v:.0f}  ({tag})", va="center", fontsize=9.5,
                color=PROXY if j[n]["hack_rate"] >= 0.5 else TRUE, fontweight="semibold")
    ax.axvline(50, color=TRUE, lw=1, ls=(0, (3, 3)))
    ax.set_yticks(y, names)
    ax.tick_params(axis="y", labelsize=9.6, labelcolor=INK)
    ax.set_xlim(0, 62)
    return save(fig, "e3_fixes.png")


def fig_concept():
    fig, gs = card(9.2, 4.4,
                   "Where reward hacking comes from",
                   "The designer has a goal, but can only hand the agent a measurable proxy. The gap is the loophole.",
                   "Original diagram by the author.",
                   top=0.80, bottom=0.10, left=0.05, right=0.95)
    ax = fig.add_subplot(GridSpec(1, 1, figure=fig, **gs)[0])
    ax.set_xlim(0, 12); ax.set_ylim(0, 5); ax.axis("off")
    def box(x, y, w, h, t, sub, col, fc):
        ax.add_patch(FancyBboxPatch((x-w/2, y-h/2), w, h, boxstyle="round,pad=0,rounding_size=0.06",
                                    fc=fc, ec=col, lw=1.5, zorder=3))
        ax.text(x, y+0.28, t, ha="center", fontsize=11, fontweight="semibold", color=INK, zorder=4)
        ax.text(x, y-0.32, sub, ha="center", fontsize=8.6, color=SUB, zorder=4)
    box(2.3, 3.6, 3.2, 1.2, "What we want", "finish the race", TRUE, "#E7F5EF")
    box(2.3, 1.2, 3.2, 1.2, "What we measure", "points on the track", PROXY, "#FBEDEC")
    box(9.4, 2.4, 3.4, 1.3, "What the agent does", "farm points forever,\nnever finish", INK, "#EEF1F6")
    ax.add_patch(FancyArrowPatch((3.9, 3.3), (7.7, 2.7), arrowstyle="-|>", mutation_scale=14,
                                 color=FAINT, lw=1.4, connectionstyle="arc3,rad=-0.15"))
    ax.add_patch(FancyArrowPatch((3.9, 1.5), (7.7, 2.1), arrowstyle="-|>", mutation_scale=14,
                                 color=PROXY, lw=2.0, connectionstyle="arc3,rad=0.15"))
    ax.text(5.8, 3.55, "intended", fontsize=8.5, color=SUB, style="italic")
    ax.text(5.8, 1.05, "optimized", fontsize=8.5, color=PROXY, fontweight="semibold")
    return save(fig, "concept_gap.png")


if __name__ == "__main__":
    for f in [fig_hacking, fig_threshold, fig_fixes, fig_concept]:
        print(f())
